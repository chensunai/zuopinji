# -*- coding: utf-8 -*-
"""
test_offline.py —— 离线自检（不需要联网）
========================================
用内置的 HTML / RSS 样例验证三件事：
  1. HtmlFetcher 的链接筛选、标题清洗、日期解析是否正确
  2. RssFetcher 对 RSS 2.0 与 Atom 两种格式是否都能解析
  3. 关键词过滤、评分、去重、消息渲染整条流水线是否跑通

运行：python test_offline.py
"""

from __future__ import annotations

import os
import sys
import tempfile

import crawler
import notify
import pipeline
from store import Store, fingerprint, norm_url

# ---------------------------------------------------------------------------
# 样例数据：模拟教育部风格列表页
# ---------------------------------------------------------------------------

SAMPLE_HTML = """<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>政策文件</title></head>
<body>
<div class="nav"><a href="/">首页</a><a href="/search">搜索</a><a href="#">更多</a></div>
<ul class="list">
  <li><a href="/jyb_xxgk/moe_1777/moe_1778/202604/t20260402_1234567.html"
        title="教育部等五部门关于印发《“人工智能+教育”行动计划》的通知">
        教育部等五部门关于印发《“人工智能+教育”行动计划》的通知</a>
      <span class="date">2026-04-02</span></li>
  <li><a href="/jyb_xxgk/moe_1777/moe_1778/202505/t20250513_1234568.html">
        教育部办公厅关于加强中小学人工智能教育的通知</a>
      <span class="date">2025-05-13</span></li>
  <li><a href="/jyb_xxgk/moe_1777/moe_1778/202412/t20241205_1234569.html">
        关于开展2025年度全国青少年科技创新大赛的通知</a>
      <span class="date">2024-12-05</span></li>
  <li><a href="/jyb_xxgk/moe_1777/moe_1778/202603/t20260310_1234570.html">
        教育部关于高等学校实验室安全管理的若干意见</a>
      <span>2026-03-10</span></li>
  <li><a href="javascript:void(0)">占位链接</a></li>
  <li><a href="https://other-site.example.com/news/1.html">外域链接应被过滤</a></li>
  <li><a href="/jyb_xxgk/moe_1777/moe_1778/202602/t20260201_1234571.pdf">PDF附件不应作为条目</a></li>
</ul>
<script>var a = "<a href='/fake/in-script.html'>脚本里的链接不该被抓</a>";</script>
</body></html>
"""

SAMPLE_RSS = """<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0"><channel>
  <title>机器之心</title><link>https://www.jiqizhixin.com</link>
  <item>
    <title><![CDATA[具身智能创业公司完成 5 亿元融资，机器狗量产提速]]></title>
    <link>https://www.jiqizhixin.com/articles/2026-10-08-1</link>
    <description>本轮融资将用于机器狗量产与教育场景落地。</description>
    <pubDate>Wed, 08 Oct 2026 09:30:00 +0800</pubDate>
  </item>
  <item>
    <title>某游戏公司发布新版本，与教育无关</title>
    <link>https://www.jiqizhixin.com/articles/2026-10-07-2</link>
    <pubDate>Tue, 07 Oct 2026 18:00:00 +0800</pubDate>
  </item>
</channel></rss>
"""

SAMPLE_ATOM = """<?xml version="1.0" encoding="utf-8"?>
<feed xmlns="http://www.w3.org/2005/Atom">
  <title>示例 Atom</title>
  <entry>
    <title>中小学人工智能通识教育指南发布</title>
    <link href="https://example.com/atom/1"/>
    <updated>2026-10-09T10:00:00+08:00</updated>
    <summary>面向小学、初中、高中的螺旋式课程体系。</summary>
  </entry>
</feed>
"""


def _fake_http_get(mapping):
    """把 crawler.http_get 换成读本地样例，避免测试依赖网络。"""

    def fake(url, timeout=25, verify_ssl=True, referer=None, headers=None):
        for key, body in mapping.items():
            if key in url:
                return body.encode("utf-8")
        raise crawler.FetchError("测试里没有为 %s 准备样例数据" % url)

    return fake


def check(name, cond, extra=""):
    mark = "PASS" if cond else "FAIL"
    print("  [%s] %s %s" % (mark, name, extra if not cond else ""))
    return cond


def main() -> int:
    results = []
    print("=" * 64)
    print("离线自检（不联网）")
    print("=" * 64)

    real_get = crawler.http_get
    crawler.http_get = _fake_http_get(
        {"moe.test": SAMPLE_HTML, "rss.test": SAMPLE_RSS, "atom.test": SAMPLE_ATOM}
    )

    try:
        # ---- 1. HTML 解析 ----
        print("\n① HtmlFetcher 列表页解析")
        html_src = {
            "id": "moe", "name": "教育部-测试", "category": "policy", "type": "html",
            "url": "https://moe.test/list.html", "verify_ssl": False,
            "html_rule": {
                "link_include": r"(/20\d{4}/|20\d{6})[^\"'?#]*\.s?html?",
                "link_exclude": r"(javascript:|\.pdf$|\.doc$|#|search|index\.s?html)",
                "min_text_length": 8, "max_text_length": 70, "same_host_only": True,
            },
        }
        items = crawler.fetch_source(html_src)
        results.append(check("抓到 4 条正文条目（排除导航/外域/PDF/脚本）", len(items) == 4,
                            "实际 %d 条: %s" % (len(items), [i["title"][:20] for i in items])))
        titles = " ".join(i["title"] for i in items)
        results.append(check("标题已清洗为纯文本", "教育部等五部门" in titles and "<a" not in titles))
        results.append(check("日期从列表页邻近位置解析成功",
                            all(i["published"] is not None for i in items),
                            str([str(i["published"]) for i in items])))
        results.append(check("URL 拼成了绝对地址",
                            all(i["url"].startswith("https://moe.test/") for i in items)))
        results.append(check("过滤掉了 PDF 附件链接",
                            not any(i["url"].endswith(".pdf") for i in items)))

        # ---- 2. RSS 2.0 ----
        print("\n② RssFetcher RSS 2.0 解析")
        rss_src = {"id": "jqzx", "name": "机器之心-测试", "category": "industry", "type": "rss",
                   "url": "https://rss.test/feed"}
        rss_items = crawler.fetch_source(rss_src)
        results.append(check("抓到 2 条 item", len(rss_items) == 2, "实际 %d" % len(rss_items)))
        results.append(check("CDATA 标题正确解析",
                            rss_items and "具身智能" in rss_items[0]["title"]))
        results.append(check("pubDate 解析为带时区 datetime",
                            rss_items and rss_items[0]["published"] is not None
                            and rss_items[0]["published"].year == 2026))
        results.append(check("description 进入 summary",
                            rss_items and "机器狗量产" in rss_items[0]["summary"]))

        # ---- 3. Atom ----
        print("\n③ RssFetcher Atom 解析")
        atom_src = {"id": "atom", "name": "Atom测试", "category": "industry", "type": "rss",
                    "url": "https://atom.test/feed"}
        atom_items = crawler.fetch_source(atom_src)
        results.append(check("Atom entry 被抓到", len(atom_items) == 1, "实际 %d" % len(atom_items)))
        results.append(check("Atom link href 正确提取",
                            atom_items and atom_items[0]["url"] == "https://example.com/atom/1",
                            atom_items[0]["url"] if atom_items else ""))

        # ---- 4. 过滤与评分 ----
        print("\n④ 关键词过滤与相关度评分")
        cfg = {
            "keywords": {"groups": [
                {"name": "教育", "weight": 3, "words": ["人工智能教育", "中小学", "科创", "研学"]},
                {"name": "行业", "weight": 2, "words": ["融资", "机器狗", "具身智能"]},
            ]},
            "filter": {"max_age_days": 400, "allow_no_keyword_pass": ["policy"]},
            "push": {"max_per_category": 5, "max_total": 12, "title_max_chars": 45,
                     "high_priority_score": 6, "show_matched_keywords": True},
        }
        allitems = items + rss_items + atom_items
        kept, dropped = pipeline.filter_and_score(allitems, cfg)
        results.append(check("命中关键词的条目被保留",
                            any("具身智能" in i["title"] for i in kept)))
        results.append(check("未命中且不允许放行的条目被丢弃",
                            any("游戏公司" in i["title"] for i in dropped),
                            "dropped=%s" % [d["title"][:16] for d in dropped]))
        results.append(check("policy 类未命中也放行",
                            any(i.get("_pass_through") for i in kept if i["category"] == "policy")))
        results.append(check("按相关度降序排列",
                            all(kept[i]["score"] >= kept[i + 1]["score"] for i in range(len(kept) - 1)),
                            str([i["score"] for i in kept])))
        hot = [i for i in kept if i["score"] >= 6]
        results.append(check("高相关条目被识别（含 🔥 标记依据）", len(hot) >= 1,
                            "scores=%s" % [i["score"] for i in kept]))

        # ---- 5. 消息渲染 ----
        print("\n⑤ 消息渲染")
        title, blocks = pipeline.render_blocks(kept, cfg)
        results.append(check("标题含日期与条数", "新增" in title and "情报站" in title))
        link_blocks = [b for b in blocks if isinstance(b, tuple)]
        results.append(check("条目渲染为可点击链接（文字+URL）",
                            len(link_blocks) >= 1 and all(b[1].startswith("http") for b in link_blocks)))
        results.append(check("命中关键词在消息中可见", any("命中" in str(b) for b in blocks)))
        preview = notify.dry_run(title, blocks)
        results.append(check("dry-run 预览可生成", len(preview) > 100))

        # ---- 6. 去重与持久化 ----
        print("\n⑥ 去重与运行历史（SQLite）")
        tmpdir = tempfile.mkdtemp(prefix="nxtest-")
        db = os.path.join(tmpdir, "t.db")
        store = Store(db)
        seen = store.existing_keys([(i["url"], i["title"]) for i in kept])
        results.append(check("首次运行无历史，全部为新条目", len(seen) == 0))
        from crawler import now_cst
        added = store.insert_items(kept, now_cst().isoformat())
        results.append(check("入库条数等于保留条数", added == len(kept), "%d vs %d" % (added, len(kept))))
        seen2 = store.existing_keys([(i["url"], i["title"]) for i in kept])
        results.append(check("第二次运行全部命中历史（不会重复推送）",
                            len(seen2) == len(kept), "%d vs %d" % (len(seen2), len(kept))))
        results.append(check("统计接口返回正确总数",
                            store.stats()["total_items"] == len(kept)))
        rid = store.start_run(now_cst().isoformat(), "test")
        store.finish_run(rid, now_cst().isoformat(), 10, added, added, "ok", {"moe": {"ok": True}})
        results.append(check("运行历史已记录", len(store.last_runs(5)) == 1))
        store.set_source_fail("moe", now_cst().isoformat(), "timeout")
        store.set_source_fail("moe", now_cst().isoformat(), "timeout")
        results.append(check("连续失败计数递增（用于告警）",
                            store.source_state("moe")["fail_count"] == 2))
        store.set_source_ok("moe", now_cst().isoformat())
        results.append(check("成功后失败计数归零",
                            store.source_state("moe")["fail_count"] == 0))
        store.close()

        # ---- 7. URL 归一化 ----
        print("\n⑦ URL 归一化（避免同一内容因参数不同被重复推送）")
        results.append(check("utm 参数不影响指纹",
                            fingerprint("https://a.cn/x?id=1&utm_source=wb")
                            == fingerprint("https://a.cn/x?id=1")))
        results.append(check("结尾斜杠不影响指纹",
                            fingerprint("https://a.cn/x/") == fingerprint("https://a.cn/x")))
        results.append(check("不同内容指纹不同",
                            fingerprint("https://a.cn/x") != fingerprint("https://a.cn/y")))
        results.append(check("norm_url 去掉 fragment",
                            "#" not in norm_url("https://a.cn/x#part")))

    finally:
        crawler.http_get = real_get

    print("\n" + "=" * 64)
    passed = sum(1 for r in results if r)
    print("结果：%d/%d 通过" % (passed, len(results)))
    print("=" * 64)
    return 0 if passed == len(results) else 1


if __name__ == "__main__":
    sys.exit(main())
