# -*- coding: utf-8 -*-
"""
notify.py —— 交付层（飞书 / 企业微信 / 钉钉 群机器人）
====================================================
题目要求「信息自动抓取并交付至微信/企业微信/飞书」。这里用群自定义机器人 Webhook 实现，
原因：无需企业认证、无需服务器公网回调，只要一个 webhook 地址就能推送，学生团队最容易落地。

全部只用标准库 urllib，POST JSON 即可。三种渠道的消息体格式不同，分别封装。

安全说明：
  * webhook 地址（含企业微信的 key、飞书的 token）等同于「谁拿到谁能往群里发消息」，
    所以一律从环境变量或 config.json 读取，代码里不硬编码，也不要提交到 git。
    config.json 里留空字符串即可，运行时用环境变量 NXWEBHOOK_FEISHU 等覆盖。
  * 飞书若开启了「签名校验」，需要 secret 做 HMAC-SHA256，下面 _feishu_sign 已实现。
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import time
import urllib.error
import urllib.request
from typing import Any, Dict, List, Optional

from crawler import FetchError, http_get  # 复用同一套超时/异常语义


class NotifyError(Exception):
    """推送失败。"""


def _post_json(url: str, payload: Dict[str, Any], timeout: int = 20) -> Dict[str, Any]:
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=body,
        headers={
            "Content-Type": "application/json; charset=utf-8",
            "User-Agent": "NextUsInfoBot/1.0",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            text = resp.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as exc:
        detail = ""
        try:
            detail = exc.read().decode("utf-8", "replace")[:300]
        except Exception:
            pass
        raise NotifyError("HTTP %s %s %s" % (exc.code, exc.reason, detail)) from exc
    except urllib.error.URLError as exc:
        raise NotifyError("连接失败: %s" % exc.reason) from exc

    try:
        return json.loads(text)
    except json.JSONDecodeError:
        raise NotifyError("返回体不是 JSON: %s" % text[:200])


def _feishu_sign(secret: str, timestamp: int) -> str:
    """飞书自定义机器人签名：HMAC-SHA256(key=timestamp+'\\n'+secret, data='')，再 base64。"""
    string_to_sign = "%d\n%s" % (timestamp, secret)
    digest = hmac.new(string_to_sign.encode("utf-8"), b"", hashlib.sha256).digest()
    return base64.b64encode(digest).decode("utf-8")


def send_feishu(webhook: str, title: str, blocks: List[str], secret: Optional[str] = None) -> None:
    """
    飞书群机器人。用富文本 post 消息，支持标题 + 多行带链接的条目。
    blocks: 每个元素是 (显示文字, 链接) 已拼好的行；这里直接当纯文本行渲染，
            为保留可点击链接，改用 post 结构的 a 标签。
    """
    content_lines: List[List[Dict[str, Any]]] = []
    for b in blocks:
        if isinstance(b, tuple):
            text, link = b
            content_lines.append([{"tag": "a", "text": text, "href": link}])
        else:
            content_lines.append([{"tag": "text", "text": str(b)}])

    payload: Dict[str, Any] = {
        "msg_type": "post",
        "content": {"post": {"zh_cn": {"title": title, "content": content_lines}}},
    }
    if secret:
        ts = int(time.time())
        payload["timestamp"] = str(ts)
        payload["sign"] = _feishu_sign(secret, ts)

    resp = _post_json(webhook, payload)
    # 飞书成功返回 {"code":0,...} 或 {"StatusCode":0,...}
    code = resp.get("code", resp.get("StatusCode", 0))
    if code not in (0, None):
        raise NotifyError("飞书返回错误: %s" % json.dumps(resp, ensure_ascii=False)[:200])


def send_wecom(webhook: str, title: str, blocks: List[str]) -> None:
    """企业微信群机器人。markdown 消息，[文字](链接) 可点击。企业微信 markdown 有 4096 字节上限，超长需分片。"""
    md = ["## %s" % title]
    for b in blocks:
        if isinstance(b, tuple):
            text, link = b
            md.append("- [%s](%s)" % (text, link))
        else:
            md.append(str(b))
    content = "\n".join(md)

    # 企业微信 markdown content 上限约 4096 字节，按字节安全分片
    chunks = _split_by_bytes(content, 3800)
    for i, ch in enumerate(chunks):
        head = ch if i == 0 else "（续%d）\n%s" % (i + 1, ch)
        resp = _post_json(webhook, {"msgtype": "markdown", "markdown": {"content": head}})
        if resp.get("errcode", 0) != 0:
            raise NotifyError("企业微信返回错误: %s" % json.dumps(resp, ensure_ascii=False)[:200])


def send_dingtalk(webhook: str, title: str, blocks: List[str], secret: Optional[str] = None) -> None:
    """钉钉群机器人。markdown 消息。若开启加签，需要 timestamp+sign 拼到 URL。"""
    md = ["### %s" % title]
    for b in blocks:
        if isinstance(b, tuple):
            text, link = b
            md.append("- [%s](%s)" % (text, link))
        else:
            md.append(str(b))

    url = webhook
    if secret:
        ts = str(round(time.time() * 1000))
        string_to_sign = "%s\n%s" % (ts, secret)
        sign = base64.b64encode(
            hmac.new(secret.encode("utf-8"), string_to_sign.encode("utf-8"), hashlib.sha256).digest()
        ).decode("utf-8")
        from urllib.parse import quote

        url = "%s&timestamp=%s&sign=%s" % (webhook, ts, quote(sign))

    resp = _post_json(url, {"msgtype": "markdown", "markdown": {"title": title, "text": "\n".join(md)}})
    if resp.get("errcode", 0) != 0:
        raise NotifyError("钉钉返回错误: %s" % json.dumps(resp, ensure_ascii=False)[:200])


def _split_by_bytes(text: str, max_bytes: int) -> List[str]:
    """按 UTF-8 字节数安全切分，不切断多字节字符。"""
    if len(text.encode("utf-8")) <= max_bytes:
        return [text]
    chunks: List[str] = []
    cur = ""
    for line in text.split("\n"):
        if len((cur + "\n" + line).encode("utf-8")) > max_bytes and cur:
            chunks.append(cur)
            cur = line
        else:
            cur = cur + "\n" + line if cur else line
    if cur:
        chunks.append(cur)
    return chunks


# ---------------------------------------------------------------------------
# 统一发送入口
# ---------------------------------------------------------------------------

CHANNELS = {
    "feishu": send_feishu,
    "wecom": send_wecom,
    "dingtalk": send_dingtalk,
}


def send(channel: str, webhook: str, title: str, blocks: List[str], secret: Optional[str] = None) -> None:
    """
    按渠道名分发。channel ∈ {feishu, wecom, dingtalk}。
    blocks 里每个元素既可是纯文本行(str)，也可是 (文字, 链接) 元组（渲染成可点击链接）。
    """
    fn = CHANNELS.get(channel)
    if fn is None:
        raise NotifyError("不支持的渠道: %s（支持 feishu / wecom / dingtalk）" % channel)
    if channel == "feishu":
        fn(webhook, title, blocks, secret=secret)
    elif channel == "dingtalk":
        fn(webhook, title, blocks, secret=secret)
    else:  # wecom 无签名参数
        fn(webhook, title, blocks)


def dry_run(title: str, blocks: List[str]) -> str:
    """
    本地预览：不联网，把消息内容拼成文本返回。
    用于录屏演示、调试排版，以及没有 webhook 时验证整条流水线跑通。
    """
    lines = ["=" * 60, title, "-" * 60]
    for b in blocks:
        if isinstance(b, tuple):
            lines.append("• %s\n  %s" % (b[0], b[1]))
        else:
            lines.append(str(b))
    lines.append("=" * 60)
    return "\n".join(lines)
