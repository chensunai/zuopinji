@echo off
chcp 65001 >nul
REM ============================================================
REM  创新战略部·自动化信息平台 —— Windows 一键运行
REM  双击本文件即执行「抓取 -> 去重 -> 过滤评分 -> 推送到群」
REM  适合配合「任务计划程序」做每日定时（见 README 第三节）
REM ============================================================

cd /d "%~dp0"

echo.
echo ============================================
echo   创新战略部·自动化信息平台
echo ============================================
echo.

REM 若已用 setx 或系统环境变量配置了 webhook，这里会自动读取；
REM 也可以取消下面这行的注释，直接写死（注意别提交到 git）：
REM set NXWEBHOOK_FEISHU=https://open.feishu.cn/open-apis/bot/v2/hook/xxxxxxxx

python main.py run
if errorlevel 1 (
    echo.
    echo [!] 本轮存在失败项，请查看上方日志，或执行 python main.py stats 排查。
) else (
    echo.
    echo [OK] 本轮执行完成。
)

echo.
pause
