# 创新战略部·自动化信息平台

一套「抓取 → 去重 → 关键词过滤 → 相关度评分 → 推送到群」的全自动情报流水线。
面向 NextUs 创新战略部日常运转：**让信息主动找到人**，而不是靠个人偶然刷到。

> **零依赖**：只用 Python 3.8+ 标准库（`urllib` / `xml.etree` / `html.parser` / `sqlite3`）。
> 不需要 `pip install` 任何东西，clone 下来就能跑 —— 评审现场不会因缺包翻车。

---

## 〇、录屏前请先做这两件事（重要）

**① 清空数据库，从「零存量」开始录。** 解压出来的 `data/nxinfo.db` 里可能已有历史数据，
会导致首次运行显示「历史已推 N 条」、飞书群里消息偏少，演示效果打折。录之前删掉它：

```powershell
Remove-Item data\nxinfo.db -ErrorAction SilentlyContinue
```

**② 先把飞书 webhook 配好，再开始录。** 环境变量只在当前 PowerShell 窗口有效，
录制中途新开窗口会失效：

```powershell
$env:NXWEBHOOK_FEISHU = "你的webhook地址"
```

**推荐录制顺序**（对应附件二里的录屏脚本）：

| 时段 | 命令 | 画面要拍到什么 |
|---|---|---|
| 0:00–0:25 | 打开 `config.json` | 三个信息源、`html_rule` 正则、五组关键词与权重 |
| 0:25–0:50 | `python main.py test` | 每个源「抓到 N 条 + 最新标题 + 日期解析」 |
| 0:50–1:30 | `python main.py fetch` | 抓到 50 → 去重 → 保留 17 → 分组排版预览 |
| 1:30–2:00 | `python main.py run` | **镜头切到飞书群**，消息实时到达、链接可点 |
| 2:00–2:20 | `python main.py run` | 显示「历史已推 17 条 / 没有新条目」，证明不刷屏 |
| 2:20–2:30 | `python main.py stats` | 累计条数、各源贡献、最近运行历史 |

`fetch` 是纯预览，**不写数据库、不发消息**，所以录完 `fetch` 再录 `run` 时，
`run` 依然能拿到完整的 17 条推送到群里 —— 这是刻意设计的，顺序不会互相干扰。
如果想反复重录某一段，删掉 `data/nxinfo.db` 就能回到初始状态。

---

## 一、30 秒跑起来

```bash
# 1. 连通性自检（逐个源试抓，逐个渠道试发）—— 录屏演示的第一步
python main.py test

# 2. 只抓取 + 本地预览推送排版，不发任何消息、也不写数据库（可反复跑）
python main.py fetch

# 3. 真实推送到群（配好 webhook 后）
python main.py run

# 4. 查看累计战果与各源健康状态
python main.py stats
```

---

## 二、配置推送渠道（唯一需要手动做的一步）

以飞书为例：群设置 → 群机器人 → 添加「自定义机器人」→ 复制 webhook 地址。

**方式 A（推荐，凭据不进代码库）**：设环境变量后运行

```powershell
# PowerShell
$env:NXWEBHOOK_FEISHU = "https://open.feishu.cn/open-apis/bot/v2/hook/xxxxxxxx"
python main.py run
```

```bash
# macOS / Linux
export NXWEBHOOK_FEISHU="https://open.feishu.cn/open-apis/bot/v2/hook/xxxxxxxx"
python main.py run
```

**方式 B**：直接把 webhook 填进 `config.json` 的 `channels[0].webhook`
（⚠ 这样凭据就在文件里了，别提交到 git）

企业微信改 `channels[1].enabled = true` 并设 `NXWEBHOOK_WECOM`；钉钉同理用 `NXWEBHOOK_DINGTALK`。
飞书/钉钉若开启了签名校验，把密钥填到 `secret` 字段或设 `NXSECRET_FEISHU` / `NXSECRET_DINGTALK`。

> 🔐 **webhook 等于「谁拿到谁能往群里发消息」**。不要截图外传，不要写进公开仓库。

---

## 三、定时运行（三选一）

### 方案 1：Windows 任务计划程序（推荐给部门公用电脑）

```powershell
# 每天早上 8:30 自动抓取并推送（注意把路径换成你的实际路径）
schtasks /Create /TN "NextUs情报站" /SC DAILY /ST 08:30 ^
  /TR "python D:\自动化信息平台\main.py run"
```

或用图形界面：任务计划程序 → 创建基本任务 → 每天 → 启动程序 → 填 `python`，
参数填 `main.py run`，起始于填平台目录。

### 方案 2：crontab（推荐放在常开的服务器/实验室机器上）

```cron
30 8 * * * cd /path/to/自动化信息平台 && /usr/bin/python3 main.py run >> data/cron.log 2>&1
```

### 方案 3：常驻进程

```bash
python main.py daemon     # 按 config 里 interval_minutes（默认 180 分钟）轮询
```

---

## 四、文件结构

```
自动化信息平台/
├── main.py          主入口：run / fetch / daemon / stats / test / report
├── config.json      信息源、关键词、推送渠道、时效窗口（改行为只改这个文件）
├── crawler.py       抓取层：RssFetcher(RSS/Atom) + HtmlFetcher(列表页正则)
├── pipeline.py      过滤层：关键词评分 + 消息渲染 + Markdown 素材归档
├── store.py         存储层：SQLite 去重 + 运行历史 + 源健康状态
├── notify.py        交付层：飞书 / 企业微信 / 钉钉群机器人
├── test_offline.py  离线自检（31 项断言，不联网）
├── run.bat          Windows 一键运行
└── data/            运行时产生：nxinfo.db + report-*.md 素材归档
```

数据流：

```
config.json ──► crawler 抓取 ──► store 去重(SQLite) ──► pipeline 过滤评分
                                                            │
                                        ┌───────────────────┴──────────────┐
                                        ▼                                  ▼
                                  notify 推送到群                    data/report-*.md
                              (飞书/企微/钉钉)                      (研究报告素材留档)
```

---

## 五、本题选定的 3 个信息源（均已实测可跑）

| # | 信息源 | 类别 | 方式 | 2026-10-10 实测结果 |
| --- | --- | --- | --- | --- |
| ① | 教育部·政策文件库 | 政策 | HTML 列表页解析 | ✓ 抓到 20 条，日期解析全部正确 |
| ② | 挑战杯官网 | 竞赛 | HTML 列表页解析 | ✓ 抓到 5 条，日期解析全部正确 |
| ③ | 芥末堆（教育行业垂直媒体） | 行业 | RSS 2.0 | ✓ 抓到 25 条（feed 共 50 条） |

选这三个的理由：分别覆盖**政策合规**（科创营课程方向）、**参赛窗口**（A 类竞赛排期）、
**竞品与融资**（商业判断），恰好对应创新战略部的三条主线。

`config.json` 里还预置了 9 个备选源（上海市教委、教育部基础教育司、量子位、IT桔子、
中国高等教育学会等），其中标注 `⚠ 实测不可用` 的 3 个已注明失败原因，改 `enabled` 即可上线。

---

## 六、如何调整抓取规则（不用改代码）

全部在 `config.json` 里：

| 想做什么 | 改哪里 |
| --- | --- |
| 换推送方向（比如开始盯「AI 硬件」） | `keywords.groups` 里加词，`weight` 决定优先级 |
| 觉得推得太多/太少 | `push.max_total`、`push.max_per_category` |
| 某个源太旧的信息也推 | 该源的 `max_age_days`（挑战杯已设为 400，因为赛季性更新） |
| 加新信息源 | `sources` 数组里复制一段，改 `url` 和 `html_rule` |
| 推送时带上摘要 | `push.show_summary = true` |
| 高亮更重要的条目 | `push.high_priority_score`（默认 ≥6 分标 🔥） |

**加新的 HTML 源怎么写 `html_rule`：**

```json
"html_rule": {
  "link_include": "(/20\\d{4}/|20\\d{6})[^\"'?#]*\\.s?html?",  // URL 必须命中的正则
  "link_exclude": "(javascript:|\\.pdf$|#|index\\.s?html)",     // 命中即丢弃
  "min_text_length": 8,     // 标题最短字数，滤掉「首页」「更多」
  "max_text_length": 70,    // 标题最长字数，滤掉整段正文被当链接
  "same_host_only": true    // 只保留同域链接
}
```

技巧：政府站正文页 URL 普遍带日期段（`/202604/t20260402_1234567.html`），
拿这个当 `link_include` 比猜 CSS 选择器稳得多，页面改版也不容易失效。

---

## 七、能力边界（诚实说明）

| 情况 | 现象 | 对策 |
| --- | --- | --- |
| **JS 动态渲染站点** | 抓到 0 条，报「未匹配到任何条目」 | 国创赛 `cy.ncss.cn`、EFG `stefg.org`、科技部实测均属此类。需换 Playwright/Selenium，或人工订阅其公众号 |
| **RSS 地址失效** | 返回 HTML 而非 XML | 机器之心 `/rss`、36氪 `/feed` 实测已失效（返回 HTML 页面）。已改用芥末堆官方 feed + 量子位 feed |
| **证书链不完整** | `CERTIFICATE_VERIFY_FAILED` | 该源设 `verify_ssl: false`（政府站与 IT桔子常见） |
| **页面改版** | 原本能抓的源突然 0 条 | `alert.fail_threshold` 会在连续失败 3 次时提示检查；`python main.py stats` 可看各源健康状态 |
| **限频封 IP** | HTTP 403 / 412 | 已内置 `politeness_delay`（默认 2.5 秒间隔）+ 浏览器 UA + Referer。不要调低于 2 秒 |

单个源失败**不会**中断整轮 —— 容错是设计要求，政府站偶尔 502 很正常。

---

## 八、测试与自检

```bash
python test_offline.py    # 31 项离线断言，不联网，验证解析/评分/去重逻辑
python main.py test       # 联网连通性自检 + 消息排版预览
```

`test_offline.py` 用内置样例覆盖了：HTML 链接筛选（排除导航/外域/PDF/脚本内链接）、
标题清洗、列表页邻近日期解析、RSS 2.0 与 CDATA、Atom 的 `link href`、
关键词过滤与放行逻辑、评分降序、消息渲染、SQLite 去重与二次运行不重推、
失败计数递增与成功归零、URL 归一化（utm 参数/结尾斜杠不影响指纹）。

---

## 九、安全注意事项

1. **webhook 与 secret 一律走环境变量**，不要提交进 git（`config.json` 里留空字符串即可）
2. `data/nxinfo.db` 含抓取历史，属内部资料，不要公开
3. 抓取频率已内置礼貌延迟，**不要**为了快把 `politeness_delay` 调到 0 —— 会被政府站封 IP，
   也可能违反站点的 robots 约定
4. 只抓公开列表页，不做登录态抓取、不绕过任何付费墙
5. 抓到的信息用于内部研判，对外引用需回到原始出处核实
