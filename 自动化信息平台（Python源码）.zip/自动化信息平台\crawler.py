# -*- coding: utf-8 -*-
"""
crawler.py —— 抓取层
====================
两种解析器，全部基于 Python 标准库（urllib + ElementTree + HTMLParser），无需 pip 安装任何第三方包：

  * RssFetcher  : 解析 RSS 2.0 / Atom，适用于 36氪、机器之心、IT桔子等提供 feed 的站点
  * HtmlFetcher : 解析任意列表页，按配置的链接白/黑名单正则提取「标题 + 链接 + 日期」，
                  适用于教育部、上海市教委等没有 RSS 的政府站点

对外统一返回 Item 字典列表，字段见 Item 说明。
"""

from __future__ import annotations

import gzip
import io
import re
import socket
import ssl
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta, timezone
from html.parser import HTMLParser
from typing import Any, Dict, Iterable, List, Optional

# ---------------------------------------------------------------------------
# 基础常量
# ---------------------------------------------------------------------------

DEFAULT_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36 NextUsInfoBot/1.0"
)

CST = timezone(timedelta(hours=8))  # Asia/Shanghai，无夏令时

# 列表页里的日期：2026-04-10 / 2026.04.10 / 2026年4月10日 / 20260410
_DATE_PATTERNS = [
    re.compile(r"(20\d{2})[-/.年](\d{1,2})[-/.月](\d{1,2})"),
    re.compile(r"/(20\d{2})(\d{2})(\d{2})"),
    re.compile(r"(20\d{2})(\d{2})(\d{2})"),
]

# <a href="...">...</a> —— 同时拿到匹配结束位置，便于向后搜索同块的日期
_A_TAG_RE = re.compile(
    r"""<a\b[^>]*?href\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))[^>]*>(.*?)</a>""",
    re.IGNORECASE | re.DOTALL,
)


# ---------------------------------------------------------------------------
# Item
# ---------------------------------------------------------------------------
# 每条抓取结果的统一数据结构：
#   source_id / source_name / category : 溯源与分类，用于消息分组
#   title                              : 标题（已清洗空白与 HTML 实体）
#   url                                : 绝对地址
#   published                          : datetime（带时区）或 None
#   summary                            : 摘要，RSS 取 description，HTML 源可留空
#   score / matched_keywords           : 由 pipeline.filter_and_score 回填


class TagStripper(HTMLParser):
    """把 HTML 片段还原成纯文本（去标签 + 解实体 + 压空白）。"""

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self._parts: List[str] = []
        self._skip = 0  # script/style 内部内容要丢掉

    def handle_starttag(self, tag: str, attrs: Any) -> None:
        if tag in ("script", "style"):
            self._skip += 1

    def handle_endtag(self, tag: str) -> None:
        if tag in ("script", "style") and self._skip:
            self._skip -= 1

    def handle_data(self, data: str) -> None:
        if not self._skip and data:
            self._parts.append(data)

    def text(self) -> str:
        return re.sub(r"\s+", " ", "".join(self._parts)).strip()


def strip_tags(html: str) -> str:
    """HTML 片段 -> 纯文本。"""
    if not html:
        return ""
    p = TagStripper()
    try:
        p.feed(html)
        p.close()
    except Exception:  # 畸形 HTML 不影响主流程，退回正则兜底
        return re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", html)).strip()
    return p.text()


# ---------------------------------------------------------------------------
# HTTP
# ---------------------------------------------------------------------------


class FetchError(Exception):
    """抓取失败（网络、超时、HTTP 状态码、解析）。"""


def http_get(
    url: str,
    timeout: int = 25,
    verify_ssl: bool = True,
    referer: Optional[str] = None,
    headers: Optional[Dict[str, str]] = None,
) -> bytes:
    """
    下载 URL，返回原始字节。

    已处理的坑：
      * gzip / deflate 响应体自动解压（urllib 不会替你解）
      * 政府站点偶发证书链不完整 -> verify_ssl=False 可跳过校验
      * 403 反爬 -> 带浏览器 UA + Referer
    """
    req_headers = {
        "User-Agent": DEFAULT_UA,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
        "Accept-Encoding": "gzip, deflate",
        "Connection": "close",
    }
    if referer:
        req_headers["Referer"] = referer
    if headers:
        req_headers.update(headers)

    ctx: Optional[ssl.SSLContext] = None
    if url.lower().startswith("https"):
        if verify_ssl:
            ctx = ssl.create_default_context()
        else:
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE

    req = urllib.request.Request(url, headers=req_headers)
    socket.setdefaulttimeout(timeout)
    try:
        with urllib.request.urlopen(req, timeout=timeout, context=ctx) as resp:
            raw = resp.read()
            enc = (resp.headers.get("Content-Encoding") or "").lower()
    except urllib.error.HTTPError as exc:
        raise FetchError("HTTP %s %s" % (exc.code, exc.reason)) from exc
    except urllib.error.URLError as exc:
        raise FetchError("连接失败: %s" % exc.reason) from exc
    except ssl.SSLError as exc:
        raise FetchError("SSL 校验失败(可在 config 里把该源 verify_ssl 设为 false): %s" % exc) from exc
    except Exception as exc:  # 超时、DNS 等
        raise FetchError("%s: %s" % (type(exc).__name__, exc)) from exc

    if "gzip" in enc:
        try:
            raw = gzip.GzipFile(fileobj=io.BytesIO(raw)).read()
        except OSError:
            pass  # 声明了 gzip 但实际没压缩，直接用原始字节
    elif "deflate" in enc:
        import zlib

        try:
            raw = zlib.decompress(raw)
        except zlib.error:
            try:
                raw = zlib.decompress(raw, -zlib.MAX_WBITS)
            except zlib.error:
                pass
    return raw


def decode_body(raw: bytes, content_type: str = "", hint_url: str = "") -> str:
    """
    字节 -> 字符串。按 Content-Type charset > meta charset > 常见中文编码 依次尝试。
    政府老站常见 gb2312/gbk，用 gb18030 兜底（gbk 的超集，不会丢字）。
    """
    m = re.search(r"charset\s*=\s*['\"]?([\w-]+)", content_type or "", re.IGNORECASE)
    candidates: List[str] = []
    if m:
        candidates.append(m.group(1))
    head = raw[:4096].decode("ascii", "ignore")
    m2 = re.search(r"charset\s*=\s*['\"]?([\w-]+)", head, re.IGNORECASE)
    if m2:
        candidates.append(m2.group(1))
    candidates += ["utf-8", "gb18030", "big5", "latin-1"]

    seen = set()
    for enc in candidates:
        if not enc:
            continue
        key = enc.lower()
        if key in seen:
            continue
        seen.add(key)
        try:
            return raw.decode(enc)
        except (UnicodeDecodeError, LookupError):
            continue
    return raw.decode("utf-8", "replace")


# ---------------------------------------------------------------------------
# RSS / Atom
# ---------------------------------------------------------------------------


def _local(tag: str) -> str:
    """去掉 XML 命名空间，'http://www.w3.org/2005/Atom{title}' -> 'title'。"""
    return tag.rsplit("}", 1)[-1].lower()


def _child_text(node: ET.Element, *names: str) -> str:
    for child in node:
        if _local(child.tag) in names:
            txt = (child.text or "").strip()
            if txt:
                return txt
            # Atom 的 link 用 href 属性
            for attr in ("href", "value"):
                if child.get(attr):
                    return child.get(attr).strip()
    return ""


def _parse_date(value: str) -> Optional[datetime]:
    """兼容 RFC822(RSS) 与 ISO8601(Atom)，解析失败返回 None 而不抛异常。"""
    if not value:
        return None
    v = value.strip()
    v = re.sub(r"\s+", " ", v)
    # RFC821 常见时区缩写
    v = re.sub(r"\bGMT\b|UT\b|\bUTC\b", "+0000", v)
    v = re.sub(r"\bCST\b", "+0800", v)

    for fmt in (
        "%a, %d %b %Y %H:%M:%S %z",
        "%d %b %Y %H:%M:%S %z",
        "%a, %d %b %Y %H:%M:%S",
        "%Y-%m-%dT%H:%M:%S%z",
        "%Y-%m-%dT%H:%M:%S.%f%z",
        "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%d",
    ):
        try:
            dt = datetime.strptime(v, fmt)
            return dt if dt.tzinfo else dt.replace(tzinfo=CST)
        except ValueError:
            continue

    # ISO8601 带冒号的时区（+08:00），Python 3.7+ fromisoformat 部分支持
    try:
        dt = datetime.fromisoformat(v.replace("Z", "+00:00"))
        return dt if dt.tzinfo else dt.replace(tzinfo=CST)
    except ValueError:
        pass

    m = re.search(r"(20\d{2})[-/.](\d{1,2})[-/.](\d{1,2})", v)
    if m:
        try:
            return datetime(int(m.group(1)), int(m.group(2)), int(m.group(3)), tzinfo=CST)
        except ValueError:
            return None
    return None


class RssFetcher:
    """RSS 2.0 / Atom 解析。source 配置示例见 config.json 中 type=rss 的条目。"""

    def fetch(self, source: Dict[str, Any]) -> List[Dict[str, Any]]:
        url = source["url"]
        raw = http_get(
            url,
            timeout=int(source.get("timeout", 25)),
            verify_ssl=bool(source.get("verify_ssl", True)),
            headers={"Accept": "application/rss+xml, application/atom+xml, application/xml"},
        )
        text = decode_body(raw, "", url)
        # 部分 feed 前有 BOM 或非法控制字符，会导致 XML 解析失败
        text = text.lstrip("\ufeff")
        text = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", text)

        try:
            root = ET.fromstring(text)
        except ET.ParseError as exc:
            raise FetchError("XML 解析失败: %s" % exc) from exc

        entries: Iterable[ET.Element] = []
        if _local(root.tag) == "rss" or root.find("channel") is not None:
            ch = root.find("channel")
            entries = [e for e in (ch if ch is not None else root) if _local(e.tag) == "item"]
        elif _local(root.tag) in ("feed", "rdf"):
            entries = [e for e in root if _local(e.tag) in ("item", "entry")]

        items: List[Dict[str, Any]] = []
        for node in entries:
            title = strip_tags(_child_text(node, "title"))
            link = _child_text(node, "link")
            if not link:  # Atom: <link href="..."/>
                for child in node:
                    if _local(child.tag) == "link" and child.get("href"):
                        link = child.get("href").strip()
                        break
            if not title or not link:
                continue
            link = urllib.parse.urljoin(url, link)

            summary = strip_tags(
                _child_text(node, "description", "summary", "content", "content:encoded")
            )
            published = _parse_date(
                _child_text(node, "pubdate", "published", "updated", "date", "dc:date")
            )

            items.append(
                {
                    "source_id": source["id"],
                    "source_name": source["name"],
                    "category": source.get("category", ""),
                    "title": title,
                    "url": link,
                    "published": published,
                    "summary": summary[:400],
                    "score": 0,
                    "matched_keywords": [],
                }
            )
        return items


# ---------------------------------------------------------------------------
# HTML 列表页
# ---------------------------------------------------------------------------


def _find_date_near(html: str, end_pos: int, url: str) -> Optional[datetime]:
    """
    找条目日期：先看链接后面 300 字符（政府站列表页通常是 <a>标题</a><span>2026-04-10</span>），
    再退回到 URL 里的日期段（/202604/t20260410_123.html 这种）。
    """
    window = html[end_pos : end_pos + 300]
    for pat in _DATE_PATTERNS:
        m = pat.search(window)
        if m:
            try:
                return datetime(int(m.group(1)), int(m.group(2)), int(m.group(3)), tzinfo=CST)
            except ValueError:
                continue
    for pat in _DATE_PATTERNS[1:]:
        m = pat.search(url)
        if m:
            try:
                return datetime(int(m.group(1)), int(m.group(2)), int(m.group(3)), tzinfo=CST)
            except ValueError:
                continue
    return None


class HtmlFetcher:
    """
    通用列表页解析器。不针对某个站点写死 XPath，而是用配置的链接规则筛选，
    这样教育部、上海市教委、科技部等结构各异的政府站可以共用同一套代码。

    html_rule 配置项：
      link_include : 正则，URL 必须命中（如 "content_|/srcsite/|/s78/"）
      link_exclude : 正则，URL 命中则丢弃（如 "javascript:|\\.pdf$|#$"）
      text_include : 正则，标题文本必须命中（可选，用于过滤导航链接）
      min_text_length : 标题最短字数，默认 8（滤掉「首页」「更多」这类）
      max_text_length : 标题最长字数，默认 80（滤掉整段正文被当成链接的情况）
      same_host_only  : 是否只保留同域链接，默认 true
    """

    def fetch(self, source: Dict[str, Any]) -> List[Dict[str, Any]]:
        url = source["url"]
        rule = source.get("html_rule") or {}
        raw = http_get(
            url,
            timeout=int(source.get("timeout", 30)),
            verify_ssl=bool(source.get("verify_ssl", True)),
            referer=source.get("referer") or url,
        )
        html = decode_body(raw, "", url)

        inc = re.compile(rule["link_include"], re.IGNORECASE) if rule.get("link_include") else None
        exc = re.compile(rule["link_exclude"], re.IGNORECASE) if rule.get("link_exclude") else None
        text_inc = (
            re.compile(rule["text_include"], re.IGNORECASE) if rule.get("text_include") else None
        )
        min_len = int(rule.get("min_text_length", 8))
        max_len = int(rule.get("max_text_length", 80))
        same_host = bool(rule.get("same_host_only", True))
        host = urllib.parse.urlparse(url).netloc.lower()

        items: List[Dict[str, Any]] = []
        seen_urls = set()

        for m in _A_TAG_RE.finditer(html):
            href = (m.group(1) or m.group(2) or m.group(3) or "").strip()
            if not href or href.startswith(("javascript:", "mailto:", "#")):
                continue
            abs_url = urllib.parse.urljoin(url, href)
            if not abs_url.startswith(("http://", "https://")):
                continue
            if same_host and urllib.parse.urlparse(abs_url).netloc.lower() != host:
                continue
            if inc and not inc.search(abs_url):
                continue
            if exc and exc.search(abs_url):
                continue

            title = strip_tags(m.group(4) or "")
            if not title:
                title = (m.group(4) or "").strip()
            title = re.sub(r"\s+", " ", title).strip(" \t\r\n·-—|")
            if len(title) < min_len or len(title) > max_len:
                continue
            if text_inc and not text_inc.search(title):
                continue

            key = abs_url.split("#")[0]
            if key in seen_urls:
                continue
            seen_urls.add(key)

            items.append(
                {
                    "source_id": source["id"],
                    "source_name": source["name"],
                    "category": source.get("category", ""),
                    "title": title,
                    "url": key,
                    "published": _find_date_near(html, m.end(), key),
                    "summary": "",
                    "score": 0,
                    "matched_keywords": [],
                }
            )
            if len(items) >= int(source.get("max_items", 40)):
                break

        if not items:
            raise FetchError(
                "列表页未匹配到任何条目，可能是页面改版或该站为 JS 动态渲染"
                "（动态渲染站点需要换用 Playwright 方案，见 README「能力边界」）"
            )
        return items


# ---------------------------------------------------------------------------
# 调度入口
# ---------------------------------------------------------------------------

FETCHERS = {"rss": RssFetcher(), "html": HtmlFetcher()}


def fetch_source(source: Dict[str, Any]) -> List[Dict[str, Any]]:
    """按 source['type'] 选择解析器抓取一个信息源。"""
    kind = (source.get("type") or "html").lower()
    fetcher = FETCHERS.get(kind)
    if fetcher is None:
        raise FetchError("未知的信息源类型: %s（支持 rss / html）" % kind)
    items = fetcher.fetch(source)
    limit = int(source.get("max_items", 40))
    # RSS 一般已按时间倒序；HTML 源保持页面顺序（列表页通常也是倒序）
    return items[:limit]


def enrich_summary(item: Dict[str, Any], source: Dict[str, Any], max_chars: int = 220) -> None:
    """
    可选增强：进详情页抽首段做摘要。
    默认关闭（config 里 source.fetch_detail=false），因为会成倍增加请求数、
    对政府站点也更容易触发限频。需要更完整的推送内容时再打开。
    """
    if item.get("summary"):
        return
    try:
        raw = http_get(
            item["url"],
            timeout=int(source.get("detail_timeout", 20)),
            verify_ssl=bool(source.get("verify_ssl", True)),
            referer=source.get("url"),
        )
    except FetchError:
        return
    text = strip_tags(decode_body(raw, "", item["url"]))
    # 去掉正文前的导航噪音：从标题出现的位置开始截取
    idx = text.find(item["title"][:12])
    body = text[idx + len(item["title"][:12]) :] if idx >= 0 else text
    body = re.sub(r"\s+", " ", body).strip()
    if len(body) > max_chars:
        body = body[:max_chars] + "…"
    item["summary"] = body


def now_cst() -> datetime:
    return datetime.now(CST)


def is_fresh(item: Dict[str, Any], max_age_days: int) -> bool:
    """没有日期的条目默认放行（宁可多推不要漏推），有日期的按 max_age_days 过滤。"""
    pub = item.get("published")
    if pub is None:
        return True
    if pub.tzinfo is None:
        pub = pub.replace(tzinfo=CST)
    return now_cst() - pub.astimezone(CST) <= timedelta(days=max_age_days)
