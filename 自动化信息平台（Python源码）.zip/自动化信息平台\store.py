# -*- coding: utf-8 -*-
"""
store.py —— 去重与运行历史
==========================
用标准库 sqlite3 做持久化，解决自动化平台最容易翻车的两个问题：

  1. 重复推送：同一条政策/新闻每次运行都被推一遍，群里很快就没人看了
  2. 无法回溯：不知道上次成功是什么时候、抓了多少条、哪个源挂了

数据库默认落在 data/nxinfo.db，单文件、零依赖、可直接拷走备份。
"""

from __future__ import annotations

import hashlib
import json
import os
import sqlite3
from datetime import datetime
from typing import Any, Dict, Iterable, List, Optional, Tuple

SCHEMA = """
CREATE TABLE IF NOT EXISTS items (
    fingerprint   TEXT PRIMARY KEY,     -- url 归一化后的 sha1
    source_id     TEXT NOT NULL,
    source_name   TEXT,
    category      TEXT,
    title         TEXT NOT NULL,
    url           TEXT NOT NULL,
    published     TEXT,                 -- ISO8601，可为空
    summary       TEXT,
    score         INTEGER DEFAULT 0,
    matched_kw    TEXT,                 -- JSON 数组，命中的关键词
    first_seen    TEXT NOT NULL,
    pushed        INTEGER DEFAULT 0,    -- 是否已成功推送
    push_channel  TEXT
);
CREATE INDEX IF NOT EXISTS idx_items_source ON items(source_id, first_seen);
CREATE INDEX IF NOT EXISTS idx_items_pushed ON items(pushed, first_seen);

CREATE TABLE IF NOT EXISTS runs (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    started_at  TEXT NOT NULL,
    finished_at TEXT,
    mode        TEXT,                   -- once / daemon / fetch
    fetched     INTEGER DEFAULT 0,
    new_items   INTEGER DEFAULT 0,
    pushed      INTEGER DEFAULT 0,
    status      TEXT,                   -- ok / partial / error
    detail      TEXT                    -- JSON：每个源的成败与条数
);

CREATE TABLE IF NOT EXISTS source_state (
    source_id  TEXT PRIMARY KEY,
    last_ok    TEXT,                    -- 上次成功抓取时间
    last_try   TEXT,                    -- 上次尝试时间
    fail_count INTEGER DEFAULT 0,       -- 连续失败次数，用于退避与告警
    last_error TEXT
);
"""


def norm_url(url: str) -> str:
    """URL 归一化：去掉 fragment、utm 类跟踪参数、结尾斜杠，避免同一条内容因参数不同被判为新条目。"""
    from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

    parts = urlsplit((url or "").strip())
    query = [
        (k, v)
        for k, v in parse_qsl(parts.query, keep_blank_values=True)
        if not k.lower().startswith(("utm_", "spm", "from", "share_"))
    ]
    path = parts.path.rstrip("/") or "/"
    return urlunsplit((parts.scheme.lower(), parts.netloc.lower(), path, urlencode(query), ""))


def fingerprint(url: str, title: str = "") -> str:
    """主键：URL 优先；URL 不稳定时（如某些 JS 站每次带不同 token）退化用标题。"""
    base = norm_url(url) or (title or "")
    return hashlib.sha1(base.encode("utf-8", "ignore")).hexdigest()


class Store:
    def __init__(self, db_path: str) -> None:
        self.db_path = db_path
        d = os.path.dirname(os.path.abspath(db_path))
        if d:
            os.makedirs(d, exist_ok=True)
        self.conn = sqlite3.connect(db_path)
        self.conn.row_factory = sqlite3.Row
        self.conn.executescript(SCHEMA)
        self.conn.commit()

    def close(self) -> None:
        try:
            self.conn.commit()
        finally:
            self.conn.close()

    # -- 去重 ---------------------------------------------------------------

    def existing_keys(self, urls_titles: Iterable[Tuple[str, str]]) -> set:
        """批量查询哪些条目已入库，返回已存在的指纹集合。一次查询代替 N 次，避免慢。"""
        keys = {fingerprint(u, t) for u, t in urls_titles}
        if not keys:
            return set()
        found = set()
        keys = list(keys)
        # sqlite 变量上限 999，分批
        for i in range(0, len(keys), 500):
            chunk = keys[i : i + 500]
            marks = ",".join("?" * len(chunk))
            rows = self.conn.execute(
                "SELECT fingerprint FROM items WHERE fingerprint IN (%s)" % marks, chunk
            ).fetchall()
            found.update(r["fingerprint"] for r in rows)
        return found

    def insert_items(self, items: List[Dict[str, Any]], now_iso: str) -> int:
        """写入新条目，返回真正新增的条数（已存在的跳过）。"""
        added = 0
        for it in items:
            fp = fingerprint(it.get("url", ""), it.get("title", ""))
            pub = it.get("published")
            pub_iso = pub.isoformat() if isinstance(pub, datetime) else (pub or None)
            cur = self.conn.execute(
                """INSERT OR IGNORE INTO items
                   (fingerprint, source_id, source_name, category, title, url,
                    published, summary, score, matched_kw, first_seen, pushed)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,0)""",
                (
                    fp,
                    it.get("source_id", ""),
                    it.get("source_name", ""),
                    it.get("category", ""),
                    it.get("title", ""),
                    it.get("url", ""),
                    pub_iso,
                    it.get("summary", ""),
                    int(it.get("score", 0)),
                    json.dumps(it.get("matched_keywords", []), ensure_ascii=False),
                    now_iso,
                ),
            )
            if cur.rowcount:
                it["_fingerprint"] = fp
                added += 1
        self.conn.commit()
        return added

    def mark_pushed(self, items: List[Dict[str, Any]], channel: str, now_iso: str) -> None:
        keys = [
            it.get("_fingerprint") or fingerprint(it.get("url", ""), it.get("title", ""))
            for it in items
        ]
        for i in range(0, len(keys), 500):
            chunk = keys[i : i + 500]
            marks = ",".join("?" * len(chunk))
            self.conn.execute(
                "UPDATE items SET pushed=1, push_channel=? WHERE fingerprint IN (%s)" % marks,
                [channel, *chunk],
            )
        self.conn.commit()

    # -- 源状态与调度 --------------------------------------------------------

    def source_state(self, source_id: str) -> Optional[sqlite3.Row]:
        return self.conn.execute(
            "SELECT * FROM source_state WHERE source_id=?", (source_id,)
        ).fetchone()

    def set_source_ok(self, source_id: str, now_iso: str) -> None:
        self.conn.execute(
            """INSERT INTO source_state (source_id, last_ok, last_try, fail_count, last_error)
               VALUES (?, ?, ?, 0, NULL)
               ON CONFLICT(source_id) DO UPDATE SET
                 last_ok=excluded.last_ok, last_try=excluded.last_try,
                 fail_count=0, last_error=NULL""",
            (source_id, now_iso, now_iso),
        )
        self.conn.commit()

    def set_source_fail(self, source_id: str, now_iso: str, error: str) -> int:
        self.conn.execute(
            """INSERT INTO source_state (source_id, last_ok, last_try, fail_count, last_error)
               VALUES (?, NULL, ?, 1, ?)
               ON CONFLICT(source_id) DO UPDATE SET
                 last_try=excluded.last_try,
                 fail_count=source_state.fail_count+1,
                 last_error=excluded.last_error""",
            (source_id, now_iso, error[:500]),
        )
        self.conn.commit()
        row = self.source_state(source_id)
        return int(row["fail_count"]) if row else 1

    # -- 运行历史 ------------------------------------------------------------

    def start_run(self, started_iso: str, mode: str) -> int:
        cur = self.conn.execute(
            "INSERT INTO runs (started_at, mode, status) VALUES (?,?, 'running')",
            (started_iso, mode),
        )
        self.conn.commit()
        return int(cur.lastrowid)

    def finish_run(
        self,
        run_id: int,
        finished_iso: str,
        fetched: int,
        new_items: int,
        pushed: int,
        status: str,
        detail: Any,
    ) -> None:
        self.conn.execute(
            """UPDATE runs SET finished_at=?, fetched=?, new_items=?, pushed=?,
                                status=?, detail=? WHERE id=?""",
            (
                finished_iso,
                fetched,
                new_items,
                pushed,
                status,
                json.dumps(detail, ensure_ascii=False),
                run_id,
            ),
        )
        self.conn.commit()

    def last_runs(self, limit: int = 10) -> List[sqlite3.Row]:
        return self.conn.execute(
            "SELECT * FROM runs ORDER BY id DESC LIMIT ?", (limit,)
        ).fetchall()

    def recent_items(self, days: int = 7, limit: int = 200) -> List[sqlite3.Row]:
        """近 N 天入库条目，用于生成日报/周报与研究素材归档。"""
        return self.conn.execute(
            """SELECT * FROM items
               WHERE first_seen >= datetime('now', ?)
               ORDER BY score DESC, first_seen DESC LIMIT ?""",
            ("-%d days" % days, limit),
        ).fetchall()

    def stats(self) -> Dict[str, Any]:
        row = self.conn.execute(
            "SELECT COUNT(*) AS total, SUM(pushed) AS pushed FROM items"
        ).fetchone()
        by_src = self.conn.execute(
            "SELECT source_name, COUNT(*) AS n FROM items GROUP BY source_name ORDER BY n DESC"
        ).fetchall()
        return {
            "total_items": row["total"] or 0,
            "pushed_items": row["pushed"] or 0,
            "by_source": {r["source_name"]: r["n"] for r in by_src},
        }
