# -*- coding: utf-8 -*-
"""
main.py —— 创新战略部·自动化信息平台（主入口）
=============================================

一条命令跑完「抓取 -> 去重 -> 关键词过滤 -> 相关度评分 -> 推送到群」全流程。

常用命令：
  python main.py fetch      只抓取+过滤，本地预览推送内容，不联网发消息（调试、录屏用）
  python main.py run        抓取并真实推送到群机器人（首次运行会推送存量，之后只推增量）
  python main.py run --dry  等价于 fetch，强制不发消息
  python main.py report     生成本轮 Markdown 素材归档到 data/（写研究报告的一手材料）
  python main.py stats      查看累计入库条数、各源贡献、最近运行历史
  python main.py daemon     常驻模式，按 config 的 interval_minutes 轮询
  python main.py test       连通性自检：逐个源试抓 1 条，逐个渠道试发一条测试消息

依赖：仅 Python 3.8+ 标准库。不需要 pip install 任何东西。
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time
import traceback
from datetime import datetime
from typing import Any, Dict, List, Tuple

import crawler
import notify
import pipeline
from crawler import FetchError, now_cst
from store import Store, fingerprint

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
DB_PATH = os.path.join(DATA_DIR, "nxinfo.db")


def log(msg: str) -> None:
    print("[%s] %s" % (now_cst().strftime("%H:%M:%S"), msg), flush=True)


def pick_sources(cfg: Dict[str, Any], only: List[str]) -> List[Dict[str, Any]]:
    """按 --source 过滤要跑的信息源；不指定则跑全部 enabled 的源。"""
    sources = [s for s in cfg.get("sources", []) if s.get("enabled", True)]
    if only:
        wanted = {x.strip().lower() for x in only}
        sources = [s for s in sources if s["id"].lower() in wanted or s["name"] in only]
        if not sources:
            raise SystemExit("没有匹配到信息源，--source 可用值：%s"
                             % ", ".join(s["id"] for s in cfg.get("sources", [])))
    return sources


def fetch_all(cfg: Dict[str, Any], sources: List[Dict[str, Any]]) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    """
    逐个源抓取，单个源失败不影响其他源（这是自动化平台必须有的容错：
    政府站点偶尔 502、RSS 偶尔超时，不能因为一个源挂了整轮就废掉）。
    源之间加 politeness_delay 秒间隔，避免被限频封 IP。
    """
    delay = float(cfg.get("crawler", {}).get("politeness_delay", 2.0))
    all_items: List[Dict[str, Any]] = []
    detail: Dict[str, Any] = {}

    for i, src in enumerate(sources):
        sid = src["id"]
        if i > 0 and delay > 0:
            time.sleep(delay)
        try:
            items = crawler.fetch_source(src)
            if src.get("fetch_detail", False):
                for it in items[: int(src.get("detail_limit", 5))]:
                    crawler.enrich_summary(it, src)
            detail[sid] = {"name": src["name"], "ok": True, "fetched": len(items), "new": 0}
            all_items.extend(items)
            log("  ✓ %-14s 抓到 %2d 条" % (sid, len(items)))
        except FetchError as exc:
            detail[sid] = {"name": src["name"], "ok": False, "fetched": 0, "new": 0, "error": str(exc)}
            log("  ✗ %-14s 失败：%s" % (sid, exc))
        except Exception as exc:  # 解析器的意外异常不能让整轮崩掉
            detail[sid] = {
                "name": src["name"], "ok": False, "fetched": 0, "new": 0,
                "error": "%s: %s" % (type(exc).__name__, exc),
            }
            log("  ✗ %-14s 异常：%s" % (sid, exc))
            if os.environ.get("NX_DEBUG"):
                traceback.print_exc()
    return all_items, detail


def do_run(cfg: Dict[str, Any], args: argparse.Namespace) -> int:
    """抓取 -> 去重 -> 过滤 -> 推送。返回进程退出码。"""
    dry = bool(args.dry) or (args.command == "fetch")
    sources = pick_sources(cfg, args.source or [])
    store = Store(args.db or DB_PATH)
    started = now_cst()
    run_id = store.start_run(started.isoformat(), "daemon" if args.command == "daemon" else args.command)

    log("开始抓取 %d 个信息源：%s" % (len(sources), ", ".join(s["name"] for s in sources)))
    items, detail = fetch_all(cfg, sources)
    log("共抓到 %d 条原始条目" % len(items))

    # 1) 去重：和历史库比对，只留没见过的
    seen = store.existing_keys([(i.get("url", ""), i.get("title", "")) for i in items])
    fresh = [i for i in items if fingerprint(i.get("url", ""), i.get("title", "")) not in seen]
    log("去重后剩 %d 条新条目（历史已推 %d 条）" % (len(fresh), len(items) - len(fresh)))

    # 2) 关键词过滤 + 相关度评分
    kept, dropped = pipeline.filter_and_score(fresh, cfg, sources)
    log("关键词过滤后保留 %d 条，丢弃 %d 条" % (len(kept), len(dropped)))

    # 3) 入库
    # 注意：dry（fetch / report 预览）模式下不写入 items 表。
    # 否则「先 fetch 预览、再 run 推送」这种最常见的演示顺序会因为条目已被记为已见，
    # 导致 run 时去重后 0 条、群里收不到任何消息。预览只负责看排版，不该留下副作用。
    now_iso = now_cst().isoformat()
    if dry:
        added = len(kept)
        log("预览模式：不写入数据库，本次 %d 条仅供排版确认" % added)
    else:
        added = store.insert_items(kept, now_iso)

    # 首轮运行会一次性推出全部存量，之后每轮只有增量。
    # 想让首轮安静一点，可以用 --max-first-run 限制条数。
    push_items = kept
    if args.max_first_run and added > args.max_first_run:
        push_items = kept[: args.max_first_run]
        log("首次运行条目较多，本轮只推送前 %d 条" % args.max_first_run)

    # 4) 推送
    title, blocks = pipeline.render_blocks(push_items, cfg)
    push_status = "skipped"
    errors: List[str] = []

    if dry:
        print()
        print(notify.dry_run(title, blocks))
        push_status = "dry-run"
    elif not push_items:
        log("没有新条目，本轮不推送（避免群里刷屏）")
        push_status = "no-new"
    else:
        channels = [c for c in cfg.get("channels", []) if c.get("enabled", True)]
        if not channels:
            log("⚠ config 里没有启用任何推送渠道，只做本地预览")
            print(notify.dry_run(title, blocks))
            push_status = "no-channel"
        for ch in channels:
            ctype = ch.get("type", "")
            webhook = (ch.get("webhook") or "").strip()
            if not webhook or webhook.startswith("请填入") or "YOUR" in webhook.upper():
                log("⚠ 渠道 %s 未配置 webhook，跳过（设置环境变量 %s 或改 config.json）"
                    % (ctype, ch.get("webhook_env", "")))
                errors.append("%s: 未配置 webhook" % ctype)
                continue
            try:
                notify.send(ctype, webhook, title, blocks, secret=ch.get("secret"))
                log("  ✓ 已推送到 %s" % ch.get("name", ctype))
                push_status = "ok"
            except notify.NotifyError as exc:
                log("  ✗ 推送 %s 失败：%s" % (ctype, exc))
                errors.append("%s: %s" % (ctype, exc))
                push_status = "partial" if push_status == "ok" else "error"
        if push_status == "ok":
            store.mark_pushed(push_items, ",".join(c.get("type", "") for c in channels), now_iso)

    # 5) 记录源状态（用于失败退避与告警）
    for sid, d in detail.items():
        if d.get("ok"):
            store.set_source_ok(sid, now_iso)
        else:
            fails = store.set_source_fail(sid, now_iso, d.get("error", ""))
            if fails >= int(cfg.get("alert", {}).get("fail_threshold", 3)):
                log("⚠ 信息源 %s 已连续失败 %d 次，可能需要检查页面是否改版" % (sid, fails))

    # 6) 写运行历史
    status = "ok" if not errors else ("partial" if push_status == "ok" else "error")
    store.finish_run(run_id, now_cst().isoformat(), len(items), added,
                     len(push_items) if push_status == "ok" else 0, status, detail)

    # 7) 可选：落一份 Markdown 素材归档
    if args.report or cfg.get("output", {}).get("always_write_report", True):
        os.makedirs(DATA_DIR, exist_ok=True)
        md = pipeline.render_report(kept, dropped, detail)
        out = os.path.join(DATA_DIR, "report-%s.md" % started.strftime("%Y%m%d-%H%M"))
        with open(out, "w", encoding="utf-8") as f:
            f.write(md)
        log("素材归档已写入 %s" % out)
        # 同时维护一个 latest 软链式副本，方便随时打开最新一份
        with open(os.path.join(DATA_DIR, "report-latest.md"), "w", encoding="utf-8") as f:
            f.write(md)

    store.close()
    if dry:
        log("本轮完成（预览）：抓到 %d 条 / 待推 %d 条 / 未写入数据库、未发送消息"
            % (len(items), len(push_items)))
    else:
        log("本轮完成：抓到 %d 条 / 新增 %d 条 / 推送 %d 条（%s）"
            % (len(items), added, len(push_items), push_status))
    return 0 if status == "ok" else 1


def do_daemon(cfg: Dict[str, Any], args: argparse.Namespace) -> int:
    """常驻轮询。适合放在服务器上跑；本机也可以用 Windows 任务计划程序定时调用 run（见 README）。"""
    interval = int(cfg.get("schedule", {}).get("interval_minutes", 180)) * 60
    log("进入常驻模式，每 %d 分钟跑一轮，Ctrl+C 退出" % (interval // 60))
    while True:
        try:
            do_run(cfg, args)
        except Exception as exc:
            log("本轮异常，%d 秒后继续：%s" % (interval // 60, exc))
            if os.environ.get("NX_DEBUG"):
                traceback.print_exc()
        try:
            time.sleep(interval)
        except KeyboardInterrupt:
            log("已退出常驻模式")
            return 0


def do_stats(cfg: Dict[str, Any], args: argparse.Namespace) -> int:
    store = Store(args.db or DB_PATH)
    st = store.stats()
    print("=" * 60)
    print("累计入库条目：%d 条，其中已推送：%d 条" % (st["total_items"], st["pushed_items"]))
    print("-" * 60)
    print("各信息源贡献：")
    for name, n in st["by_source"].items():
        print("  %-22s %d 条" % (name, n))
    print("-" * 60)
    print("最近 10 次运行：")
    for r in store.last_runs(10):
        print("  %s  %-8s 抓%3d 新%3d 推%3d  %s"
              % ((r["started_at"] or "")[:19], r["mode"] or "-", r["fetched"] or 0,
                 r["new_items"] or 0, r["pushed"] or 0, r["status"] or ""))
    print("-" * 60)
    print("信息源健康状态：")
    for s in cfg.get("sources", []):
        row = store.source_state(s["id"])
        if row is None:
            print("  %-14s 尚未运行" % s["id"])
        else:
            print("  %-14s 上次成功 %s ｜连续失败 %d 次 %s"
                  % (s["id"], (row["last_ok"] or "无")[:19], row["fail_count"] or 0,
                     ("｜最近错误: " + str(row["last_error"])[:60]) if row["fail_count"] else ""))
    print("=" * 60)
    store.close()
    return 0


def do_test(cfg: Dict[str, Any], args: argparse.Namespace) -> int:
    """
    连通性自检。录屏演示的第一步：证明「抓取规则真的能抓到东西」「推送渠道真的通」。
    """
    print("=" * 60)
    print("① 信息源连通性测试")
    print("=" * 60)
    ok_n = 0
    for src in cfg.get("sources", []):
        if not src.get("enabled", True):
            continue
        try:
            items = crawler.fetch_source(src)
            ok_n += 1
            print("  ✓ [%s] %s" % (src["id"], src["name"]))
            print("     抓到 %d 条，最新一条：%s" % (len(items), items[0]["title"][:50] if items else "无"))
            if items and items[0].get("published"):
                print("     日期解析：%s" % items[0]["published"].strftime("%Y-%m-%d"))
        except Exception as exc:
            print("  ✗ [%s] %s -> %s" % (src["id"], src["name"], exc))
    print()
    print("=" * 60)
    print("② 推送渠道测试")
    print("=" * 60)
    test_blocks = [
        ("这是一条自检消息，收到说明机器人配置正确", "https://nextus.net.cn/camp"),
        "如果你看到这条，说明创新战略部情报站已上线",
    ]
    for ch in cfg.get("channels", []):
        if not ch.get("enabled", True):
            continue
        webhook = (ch.get("webhook") or "").strip()
        if not webhook or webhook.startswith("请填入") or "YOUR" in webhook.upper():
            print("  - [%s] 未配置 webhook，跳过（可用 --dry 预览消息排版）" % ch.get("type"))
            continue
        try:
            notify.send(ch["type"], webhook, "【情报站自检】%s" % now_cst().strftime("%m-%d %H:%M"),
                        test_blocks, secret=ch.get("secret"))
            print("  ✓ [%s] 测试消息已发送，请到群里确认" % ch.get("type"))
        except Exception as exc:
            print("  ✗ [%s] 发送失败：%s" % (ch.get("type"), exc))
    print()
    print("=" * 60)
    print("③ 消息排版预览（不联网）")
    print("=" * 60)
    fake = [
        {"source_id": "demo", "source_name": "演示源", "category": "policy", "score": 8,
         "title": "教育部等五部门印发《“人工智能+教育”行动计划》", "url": "https://www.moe.gov.cn/",
         "published": now_cst(), "matched_keywords": ["人工智能教育", "教育部"], "summary": ""},
    ]
    t, b = pipeline.render_blocks(fake, cfg)
    print(notify.dry_run(t, b))
    return 0 if ok_n else 1


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="main.py",
        description="NextUs 创新战略部·自动化信息平台（抓取政策/竞赛/行业情报并推送到群）",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    p.add_argument("command", choices=["run", "fetch", "daemon", "stats", "test", "report"],
                   help="run=抓取并推送 | fetch=只抓取本地预览 | daemon=常驻轮询 | stats=统计 | test=连通性自检")
    p.add_argument("-c", "--config", help="配置文件路径，默认同目录 config.json")
    p.add_argument("--db", help="SQLite 数据库路径，默认 data/nxinfo.db")
    p.add_argument("--source", action="append",
                   help="只跑指定信息源（可重复），值为 config 里的 id，如 --source moe")
    p.add_argument("--dry", action="store_true", help="不真实推送，只本地预览")
    p.add_argument("--report", action="store_true", help="本轮额外生成 Markdown 素材归档")
    p.add_argument("--max-first-run", type=int, default=0,
                   help="首轮推送条数上限，0 表示不限制（首轮存量多时建议设 10）")
    return p


def main(argv: List[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        cfg = pipeline.load_config(args.config)
    except (FileNotFoundError, json.JSONDecodeError) as exc:
        print("配置加载失败：%s" % exc, file=sys.stderr)
        return 2

    os.makedirs(DATA_DIR, exist_ok=True)

    if args.command == "stats":
        return do_stats(cfg, args)
    if args.command == "test":
        return do_test(cfg, args)
    if args.command == "daemon":
        return do_daemon(cfg, args)
    if args.command == "report":
        args.report = True
        args.dry = True
        return do_run(cfg, args)
    return do_run(cfg, args)


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("\n已中断")
        sys.exit(130)
