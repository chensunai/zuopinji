# -*- coding: utf-8 -*-
"""
pipeline.py —— 过滤、评分与消息渲染
==================================
抓取层给的是「这个源最近更新了什么」，这一层要解决的是「哪几条值得推给部门、按什么顺序推」。

三件事：
  1. 关键词过滤：只留下与团队业务（中小学 AI 教育、科创营、大学生竞赛、AI 融资）相关的条目
  2. 相关度评分：命中关键词数量 + 高权重词 + 时效性，决定排序与是否进「高优先级」
  3. 消息渲染：按类别分组、控制条数、截断标题，生成群里可读的推送文本

设计取舍：
  * 政府站列表页每天只有几条，用关键词过滤会漏掉「没提到 AI 但其实是重要政策」的条目，
    所以 config 里 allow_no_keyword_pass 默认对 policy 类别放行 —— 政策源宁可多看一眼。
"""

from __future__ import annotations

import json
import os
import re
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Tuple

from crawler import CST, now_cst

# ---------------------------------------------------------------------------
# 配置加载
# ---------------------------------------------------------------------------

DEFAULT_CONFIG_NAME = "config.json"


def load_config(path: Optional[str] = None) -> Dict[str, Any]:
    """
    读 config.json，并用环境变量覆盖敏感项（webhook / secret）。
    这样代码可以公开、可以进 git，凭据留在本机环境里。
    """
    cfg_path = path or os.path.join(os.path.dirname(os.path.abspath(__file__)), DEFAULT_CONFIG_NAME)
    if not os.path.exists(cfg_path):
        raise FileNotFoundError("找不到配置文件: %s" % cfg_path)
    with open(cfg_path, "r", encoding="utf-8") as f:
        cfg = json.load(f)

    env_map = {
        "feishu": ("NXWEBHOOK_FEISHU", "NXSECRET_FEISHU"),
        "wecom": ("NXWEBHOOK_WECOM", "NXSECRET_WECOM"),
        "dingtalk": ("NXWEBHOOK_DINGTALK", "NXSECRET_DINGTALK"),
    }
    for ch in cfg.get("channels", []):
        keys = env_map.get(ch.get("type", ""))
        if not keys:
            continue
        env_url, env_secret = keys
        if os.environ.get(env_url):
            ch["webhook"] = os.environ[env_url]
        if os.environ.get(env_secret):
            ch["secret"] = os.environ[env_secret]
    return cfg


# ---------------------------------------------------------------------------
# 过滤与评分
# ---------------------------------------------------------------------------


def _compile_rules(kw_cfg: Dict[str, Any]) -> List[Tuple[str, re.Pattern, int]]:
    """把 config 里的关键词编译成正则。支持字符串或 {word, weight} 两种写法。"""
    rules: List[Tuple[str, re.Pattern, int]] = []
    for group in kw_cfg.get("groups", []):
        weight = int(group.get("weight", 1))
        for w in group.get("words", []):
            word = w if isinstance(w, str) else str(w.get("word", ""))
            if not word:
                continue
            # 关键词按字面匹配（转义），中英文都要能命中；忽略大小写
            rules.append((word, re.compile(re.escape(word), re.IGNORECASE), weight))
    return rules


def score_item(item: Dict[str, Any], rules: List[Tuple[str, re.Pattern, int]]) -> None:
    """就地回填 item['score'] 与 item['matched_keywords']。"""
    text = "%s %s" % (item.get("title", ""), item.get("summary", ""))
    hit_words: List[str] = []
    score = 0
    for word, pat, weight in rules:
        n = len(pat.findall(text))
        if n:
            hit_words.append(word)
            score += weight * min(n, 3)  # 同一个词重复命中最多计 3 次，避免标题堆词刷分
    # 时效加成：越新越靠前
    pub = item.get("published")
    if isinstance(pub, datetime):
        age_days = (now_cst() - pub.astimezone(CST)).total_seconds() / 86400.0
        if age_days <= 1:
            score += 3
        elif age_days <= 3:
            score += 2
        elif age_days <= 7:
            score += 1
    item["score"] = score
    item["matched_keywords"] = hit_words


def filter_and_score(
    items: List[Dict[str, Any]], cfg: Dict[str, Any], sources: Optional[List[Dict[str, Any]]] = None
) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    """
    返回 (保留的条目, 被丢弃的条目)。
    规则：
      * 命中关键词 -> 保留
      * 未命中，但该源 allow_no_keyword_pass=true -> 保留但标记为低分（政策源用）
      * 未命中且不允许放行 -> 丢弃
      * 超过时效窗口的旧条目 -> 丢弃

    时效窗口支持按源覆盖（source["max_age_days"]）。这一条很重要：
    挑战杯、大挑这类竞赛源是赛季性更新，官网可能两三个月没动静，
    用统一的 45 天窗口会把整个竞赛类全部过滤光，等于白配。
    """
    kw_cfg = cfg.get("keywords", {})
    rules = _compile_rules(kw_cfg)
    default_age = int(cfg.get("filter", {}).get("max_age_days", 30))
    pass_categories = set(cfg.get("filter", {}).get("allow_no_keyword_pass", []))
    # 源级时效覆盖表
    age_by_source: Dict[str, int] = {}
    for s in sources or []:
        if s.get("max_age_days"):
            age_by_source[s["id"]] = int(s["max_age_days"])

    keep: List[Dict[str, Any]] = []
    drop: List[Dict[str, Any]] = []

    for it in items:
        score_item(it, rules)

        max_age = age_by_source.get(it.get("source_id", ""), default_age)
        pub = it.get("published")
        if isinstance(pub, datetime):
            pub_cst = pub.astimezone(CST)
            if now_cst() - pub_cst > timedelta(days=max_age):
                it["_drop_reason"] = "超过 %d 天（%s）" % (max_age, pub_cst.date())
                drop.append(it)
                continue

        if it["matched_keywords"]:
            keep.append(it)
        elif it.get("category", "") in pass_categories:
            it["score"] = max(it["score"], 1)
            it["_pass_through"] = True
            keep.append(it)
        else:
            it["_drop_reason"] = "未命中任何关键词"
            drop.append(it)

    keep.sort(key=lambda x: (x["score"], x.get("published") or datetime.min.replace(tzinfo=CST)), reverse=True)
    return keep, drop


# ---------------------------------------------------------------------------
# 消息渲染
# ---------------------------------------------------------------------------

CATEGORY_LABEL = {"policy": "政策动态", "competition": "竞赛信息", "industry": "行业情报"}


def _fmt_date(item: Dict[str, Any]) -> str:
    pub = item.get("published")
    return pub.astimezone(CST).strftime("%m-%d") if isinstance(pub, datetime) else ""


def _trim(text: str, limit: int) -> str:
    text = re.sub(r"\s+", " ", text).strip()
    return text if len(text) <= limit else text[: limit - 1] + "…"


def render_blocks(items: List[Dict[str, Any]], cfg: Dict[str, Any]) -> Tuple[str, List[Any]]:
    """
    生成推送标题与内容块。
    返回 (title, blocks)；blocks 元素为 str（纯文本行）或 (文字, 链接) 元组（渲染成可点击链接）。
    """
    limit_cfg = cfg.get("push", {})
    per_category = int(limit_cfg.get("max_per_category", 5))
    total_limit = int(limit_cfg.get("max_total", 12))
    title_limit = int(limit_cfg.get("title_max_chars", 45))
    show_kw = bool(limit_cfg.get("show_matched_keywords", True))
    high_score = int(limit_cfg.get("high_priority_score", 6))

    today = now_cst().strftime("%Y-%m-%d %H:%M")
    hot = [i for i in items if i["score"] >= high_score]
    title = "【创新战略部情报站】%s ｜新增 %d 条" % (today, len(items))
    if hot:
        title += "（%d 条高相关）" % len(hot)

    blocks: List[Any] = []
    order = ["policy", "competition", "industry"]
    cats = [c for c in order if any(i.get("category") == c for i in items)]
    cats += [c for c in {i.get("category", "") for i in items} if c and c not in cats]

    used = 0
    for cat in cats:
        cat_items = [i for i in items if i.get("category") == cat][:per_category]
        if not cat_items:
            continue
        label = CATEGORY_LABEL.get(cat, cat or "其他")
        blocks.append("📌 %s（%d 条）" % (label, len(cat_items)))
        for it in cat_items:
            if used >= total_limit:
                break
            d = _fmt_date(it)
            prefix = "🔥" if it["score"] >= high_score else "·"
            line = "%s [%s]%s %s" % (prefix, d, (" " + it["source_name"]) if d else it["source_name"],
                                     _trim(it["title"], title_limit))
            if not d:
                line = "%s %s %s" % (prefix, it["source_name"], _trim(it["title"], title_limit))
            blocks.append((line, it["url"]))
            if show_kw and it.get("matched_keywords"):
                blocks.append("   命中: %s ｜相关度 %d" % ("、".join(it["matched_keywords"][:4]), it["score"]))
            summary = (it.get("summary") or "").strip()
            if summary and limit_cfg.get("show_summary", False):
                blocks.append("   %s" % _trim(summary, 80))
            used += 1
        blocks.append("")

    if used == 0:
        blocks.append("本轮没有符合条件的新信息，下一轮继续盯。")
    return title, blocks


def render_report(items: List[Dict[str, Any]], dropped: List[Dict[str, Any]], detail: Dict[str, Any]) -> str:
    """
    生成 Markdown 素材归档（data/report-YYYYMMDD-HHMM.md）。
    用途：附件三《深度研究报告》的一手素材留档，也方便回溯「这条建议当时是基于哪条信息提出的」。
    """
    lines = [
        "# 情报抓取报告",
        "",
        "- 生成时间：%s" % now_cst().strftime("%Y-%m-%d %H:%M:%S"),
        "- 保留条目：%d 条；过滤丢弃：%d 条" % (len(items), len(dropped)),
        "",
        "## 各信息源抓取情况",
        "",
        "| 信息源 | 状态 | 抓到 | 新增 | 备注 |",
        "| --- | --- | --- | --- | --- |",
    ]
    for sid, d in detail.items():
        lines.append(
            "| %s | %s | %s | %s | %s |"
            % (d.get("name", sid), "成功" if d.get("ok") else "失败", d.get("fetched", 0),
               d.get("new", 0), _trim(str(d.get("error", "")), 60) or "-")
        )
    lines += ["", "## 保留条目（按相关度排序）", ""]
    for i, it in enumerate(items, 1):
        pub = _fmt_date(it)
        lines.append(
            "%d. **%s**（%s%s）｜相关度 %d%s"
            % (i, it["title"], it.get("source_name", ""), (" " + pub) if pub else "", it["score"],
               ("｜命中: " + "、".join(it["matched_keywords"])) if it.get("matched_keywords") else "")
        )
        lines.append("   %s" % it["url"])
        if it.get("summary"):
            lines.append("   > %s" % _trim(it["summary"], 150))
        lines.append("")

    if dropped:
        lines += ["## 被过滤条目（抽样 20 条）", ""]
        for it in dropped[:20]:
            lines.append("- %s ｜原因：%s" % (_trim(it["title"], 50), it.get("_drop_reason", "")))
        lines.append("")
    return "\n".join(lines)
